<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Score;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ScoreController extends Controller
{
    public function leaderboard($game_type)
    {

        // $customers = Score::selectRaw('customer_id,game_type,AVG(score) as average_score')
        // ->groupBy('customer_id')
        // ->with('customer')
        // ->get();
    if($game_type == 'all')
    {
    $all_customers = Score::selectRaw('customer_id,SUM(score) as sum_score')
    ->groupBy('customer_id')
    ->orderBy('sum_score','DESC')
    ->get();

    // dd($all_customers);

        foreach ($all_customers as $customers) {
            $score = $customers->sum_score;
            $name = $customers->customer->name ?? null;
            $scores[] = [
                'name' => $name,
                'score ' =>  $score,
            ];
        }
    }
    elseif($game_type == 'malware')
    {
        $all_customers = Score::selectRaw('customer_id,game_type, SUM(score) as sum_score')
        ->groupBy('customer_id', 'game_type')
        ->orderBy('sum_score', 'DESC')
        ->where('game_type', 'malware') // Assuming you want to filter by game_type "matach"
        ->get();

    // dd($all_customers);

        foreach ($all_customers as $customers) {
            $score = $customers->sum_score;
            $name = $customers->customer->name ?? null;
            $scores[] = [
                'name' => $name,
                'score ' =>  $score,
            ];
        }
    }
    elseif($game_type == 'hack_attack')
    {
        $all_customers = Score::selectRaw('customer_id,game_type, SUM(score) as sum_score')
        ->groupBy('customer_id', 'game_type')
        ->orderBy('sum_score', 'DESC')
        ->where('game_type', 'hack_attack') // Assuming you want to filter by game_type "matach"
        ->get();

    // dd($all_customers);

        foreach ($all_customers as $customers) {
            $score = $customers->sum_score;
            $name = $customers->customer->name ?? null;
            $scores[] = [
                'name' => $name,
                'score ' =>  $score,
            ];
        }
    }
    elseif($game_type == 'attack')
    {
        $all_customers = Score::selectRaw('customer_id,game_type, SUM(score) as sum_score')
        ->groupBy('customer_id', 'game_type')
        ->orderBy('sum_score', 'DESC')
        ->where('game_type', 'attack') // Assuming you want to filter by game_type "matach"
        ->get();

    // dd($all_customers);

        foreach ($all_customers as $customers) {
            $score = $customers->sum_score;
            $name = $customers->customer->name ?? null;
            $scores[] = [
                'name' => $name,
                'score ' =>  $score,
            ];
        }
    }
    else
    {
        $scores[] = [
            'message' =>  'Data Not Found',
        ];
    }


        return response()->json($scores);

    }

    }

