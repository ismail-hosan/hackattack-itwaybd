<!-- Header section -->
<header class="header-section">
    <div class="header-warp">
        <div class="header-social d-flex justify-content-end">
            <p>Follow us:</p>
            <a href="#"><i class="fa fa-pinterest"></i></a>
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-dribbble"></i></a>
            <a href="#"><i class="fa fa-behance"></i></a>
        </div>
        <div class="header-bar-warp d-flex">
            <!-- site logo -->
            <a href="<?php echo e(Url('/')); ?>" class="site-logo">
                <img src="<?php echo e(asset('font_assets/img/logo.png')); ?>" alt="">
            </a>
            <nav class="top-nav-area w-100">
                <div class="user-panel">
                    <?php if(Auth::guard('customer')->user()): ?>
                    <a href="http://">Dashboard</a>
                    <?php elseif(Auth::user()): ?>
                    <a href="<?php echo e(Route('home')); ?>">Dashboard</a>
                    <?php else: ?>
                    <a href="<?php echo e(Route('user_show_page')); ?>">Login</a> / <a href="<?php echo e(Route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
                <!-- Menu -->
                <ul class="main-menu primary-menu">
                    <li><a href="<?php echo e(Url('/')); ?>">Home</a></li>
                    <li><a href="games.html">Games</a>
                        <ul class="sub-menu">
                            <li><a href="game-single.html">Game Singel</a></li>
                        </ul>
                    </li>
                    <li><a href="review.html">Reviews</a></li>
                    <li><a href="blog.html">News</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<!-- Header section end -->


<?php /**PATH /home/itwaybds/hackattack.itwaybdsoft.com/resources/views/fontend/parsial/header.blade.php ENDPATH**/ ?>