
<?php $__env->startSection('content'); ?>

<div class="content-wrapper" style="overflow-y:auto">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add Slider</h4>
                <form class="forms-sample" action="<?php echo e(Route('slider_store')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="exampleInputName1">Heading</label>
                        <input type="text" class="form-control" name="heading" id="exampleInputName1" value=""
                            placeholder="Heading" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputName2">Description</label>
                        <input type="text" class="form-control" name="description" id="exampleInputName2" value=""
                            placeholder="Description" required>

                    </div>

                    <div class="form-group">
                        <label for="exampleInputName4">Select Image</label>
                        <input type="file" class="form-control" name="image" value="" id="exampleInputName4"
                            placeholder="3rd Option" required>

                    </div>

                    <button type="submit" class="btn btn-primary me-2">Add Slider</button>
                    <button class="btn btn-dark">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>
<style>
    .form-group {
        margin-bottom: 1.5rem;
    }
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/itwaybds/hackattack.itwaybdsoft.com/resources/views/admin/pages/slider/add.blade.php ENDPATH**/ ?>