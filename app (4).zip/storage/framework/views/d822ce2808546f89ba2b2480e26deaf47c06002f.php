<?php $__env->startSection('content'); ?>

<div class="content-wrapper vh-100">
    <div class="row">
      <div class="col-xl-3 col-sm-4 grid-margin stretch-card">

        <div class="card">
            <a href="<?php echo e(route('game_add', ['type' => 'fishing'])); ?>"  class="btn btn-success"><i class="fa fa-plus" style="font-size:25px"></i></a>
            <img class="card-img" src="<?php echo e(asset('font_assets/img/add.jpg')); ?>" alt="Card image cap">

        </div>
    </div>
    <div class="col-xl-3 col-sm-6 grid-margin stretch-card">

        <div class="card">
            <a href="<?php echo e(route('game_add', ['type' => 'password_attack'])); ?>" class="btn btn-success"><i class="fa fa-plus" style="font-size:25px"></i></a>
            <img class="card-img" src="<?php echo e(asset('font_assets/img/add.jpg')); ?>" alt="Card image cap">

        </div>
    </div>
    <div class="col-xl-3 col-sm-6 grid-margin stretch-card">

        <div class="card">
            <a href="<?php echo e(route('game_add', ['type' => 'malware'])); ?>" class="btn btn-success"><i class="fa fa-plus" style="font-size:25px"></i></a>
            <img class="card-img" src="<?php echo e(asset('font_assets/img/add.jpg')); ?>" alt="Card image cap">

        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\hacker_attack\resources\views/admin/pages/game/index.blade.php ENDPATH**/ ?>